package com.example.registrationapp2;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class DataBaseHelper extends SQLiteOpenHelper {
    public DataBaseHelper(@Nullable Context context) {
        super(context,"UserDb.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
    DB.execSQL("create Table UserDetails(name TEXT primary key, dob TEXT, email TEXT)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        SQLiteDatabase DB = null;
        assert false;
        DB.execSQL("drop Table if exists UserDetails");
    }
    public boolean insertuserdata(String name, String dob,String email)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues=new ContentValues(0);
        contentValues.put("name", name);
        contentValues.put("dob", dob);
        contentValues.put("email", email);
        long result=DB.insert("UserDetails",null, contentValues);
        return result != -1;
    }
    public Cursor getdata ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        try (Cursor cursor = DB.rawQuery("Select * from UserDetails", null)) {
            return cursor;
        }
    }
}

package com.example.registrationapp2;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity2 extends AppCompatActivity {

    private static final DataBaseHelper DB = null ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second2);
        //public Cursor getdata ()
        //{
            //SQLiteDatabase DB = this.getWritableDatabase();
           // Cursor cursor = DB rawQuery("Select * from User")
        assert false;
        Cursor res=DB.getdata();
        if(res.getCount()==0){
            Toast.makeText(SecondActivity2.this, "No entry exists", Toast.LENGTH_SHORT).show();
        return;
        }
        StringBuilder buffer = new StringBuilder();
        while(res.moveToNext()){
            buffer.append("name : ").append(res.getString(0)).append("\n");
            buffer.append("date of birth : ").append(res.getString(0)).append("\n");
            buffer.append("email : ").append(res.getString(0)).append("\n\n");

        }
        AlertDialog.Builder builder=new AlertDialog.Builder(SecondActivity2.this);
        builder.setCancelable(true);
        builder.setTitle("User Entries");
        builder.setMessage(buffer.toString());
        builder.show();

    }
}
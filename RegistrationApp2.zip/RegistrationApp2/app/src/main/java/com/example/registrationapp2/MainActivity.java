package com.example.registrationapp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText name, dob, email;
    Button submit;
    DataBaseHelper DB = new DataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextTextPersonName);
        dob = findViewById(R.id.editTextDate);
        email = findViewById(R.id.editTextTextEmailAddress);

        submit = findViewById(R.id.button);
        submit.setOnClickListener(this::onClick);


    }

    private void onClick(View view) {
        String nameTXT = name.getText().toString();
        String dobTXT = dob.getText().toString();
        String emailTXT = email.getText().toString();
        boolean checkinserteddata = DB.insertuserdata(nameTXT, dobTXT, emailTXT);
        if (checkinserteddata) {
            Toast.makeText(MainActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "New Entry is not inserted", Toast.LENGTH_SHORT).show();
        }
        Intent MainActivityIntent = new Intent(getApplicationContext(), SecondActivity2.class);
        startActivity(MainActivityIntent);
    }
}